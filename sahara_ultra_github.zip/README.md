
# SAHARA Premium Wear — Ultra Site

**Live URL:** https://solarpowergo.github.io/sahara/

A polished, single-file website for *Sahara Premium Wear* with a cinematic splash,
shop cards, demo cart drawer, lightbox gallery, size guide, story, reviews, FAQ,
and SEO (OpenGraph + JSON‑LD). No build tools or external libraries.

## Quick Publish (GitHub Pages)
1. Open your repo: `https://github.com/solarpowergo/sahara`
2. Upload these files to the **repo root**: `index.html`, `prototype.jpg`, `hoodie.jpg`, `pants.jpg`, `README.md` (replace old files).
3. Go to **Settings → Pages** → **Build and deployment**:
   - **Source:** Deploy from a branch
   - **Branch:** `main` · **Folder:** `/ (root)` → **Save`
4. In ~1 minute your site will be live at **https://solarpowergo.github.io/sahara/**

## Files
- `index.html` — single-file site (~1500 lines: HTML+CSS+JS)
- `prototype.jpg` — hero splash image (as in the mockup)
- `hoodie.jpg` — product image
- `pants.jpg` — product image

## Customize
- Prices, copy, and sizes are editable inside `index.html`.
- To connect real checkout: integrate Stripe/PayPal/Shopify where the `Checkout` button is.
- Add a custom domain in **Settings → Pages → Custom domain** (optional).

---

© 2025 Sahara Premium Wear. Demo for portfolio/publishing.
